package com.example.demowebsankul

class ModelClass {

//    var id: Int = null
    var cname: String = ""
    var mname: String = ""
    var price: String = ""
    var nplate: String = ""


//    constructor(cmp: String, model: String , price : String , numberP : String) {
//        this.cname = cmp
//        this.mname = model
//        this.price = price
//        this.nplate = numberP
//    }
//
//
//    constructor(id:Int,cmp: String, model: String,price: String,numberP: String) {
//        this.cname = cmp
//        this.mname = model
//        this.price = price
//        this.nplate = numberP
//        this.id =id
//    }
//
//    constructor(id : Int){
//        this.id = id
//    }

}