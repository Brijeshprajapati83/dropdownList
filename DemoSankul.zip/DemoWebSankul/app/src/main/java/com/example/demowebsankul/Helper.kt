package com.example.demowebsankul

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast


private   const val DATABASE_NAME = "MahadevDB"

    private const val ID = "id"
   private const val TABLE_NAME = "studenttable"
    val cmp_Name = "name"
    val modl_Name = "modelName"
    val price_P = "priceP"
    val number_Plate = "numberPlate"


class Helper(val context: Context) : SQLiteOpenHelper(context,DATABASE_NAME,null,1) {


    override fun onCreate(db: SQLiteDatabase) {
        val createtable =
            "CREATE TABLE $TABLE_NAME($ID INTEGER PRIMARY KEY,$cmp_Name TEXT,$modl_Name TEXT,$price_P TEXT,$number_Plate TEXT)"
  db.execSQL(createtable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        db?.let { onCreate(it) }

    }

    fun insertdata(modelClass: ModelClass) {
        var db = this.writableDatabase

        val values = ContentValues()
        values.put(cmp_Name, modelClass.cname)
        values.put(modl_Name, modelClass.mname)
        values.put(price_P, modelClass.price)
        values.put(number_Plate, modelClass.nplate)
        val result = db.insert(TABLE_NAME, null, values)
        if (result == (0).toLong())
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show()
        else
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show()

    }

    @SuppressLint("Range")
    fun readdata(): MutableList<ModelClass> {
        var list: MutableList<ModelClass> = ArrayList()
        var db = this.readableDatabase

        val query = "select * from $TABLE_NAME"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            do {
                var modelClass : ModelClass
//                modelClass.id = result.getString(result.getColumnIndex(ID)).toInt()
//                modelClass.id = result.getString(result.getColumnIndex(ID)).toInt()
//                modelClass.cname = result.getString(result.getColumnIndex(cmp_Name))
//                modelClass.mname = result.getString(result.getColumnIndex(modl_Name))
//                modelClass.price = result.getString(result.getColumnIndex(price_P))
//                modelClass.nplate = result.getString(result.getColumnIndex(number_Plate))
//                list.add(modelClass)
            } while (result.moveToNext())
        }

        result.close()

        return list
    }

//    fun updatedata(user: User): Boolean {
//
//        val db = this.writableDatabase
//        val contentValues = ContentValues()
//        contentValues.put(ID, user.id)
//        contentValues.put(NAME_M, user.name)
//        contentValues.put(AGE_G, user.age)
//        db.update(TABLE_NAME, contentValues, "$ID=?", arrayOf(user.id.toString())).toLong()
//        return true
//    }
//
//    fun deletdata(user: User): Int {
//        val db = this.writableDatabase
//        val success = db.delete(TABLE_NAME, "$ID=?",
//            arrayOf(arrayOf(user.id).toString()))
//        db.close()
//        return success
//
//    }
}



//        var db = this.writableDatabase
//
//        val query = "Select * From $TABLE_NAME"
//        val result = db.rawQuery(query, null)
//        if (result.moveToFirst()) {
//            do {
//                var values = ContentValues()
//                values.put(ID, (result.getInt(result.getColumnIndex(ID)) + 1))
//                db.update(TABLE_NAME, values, "$ID=? AND $NAME_M=?",
//                    arrayOf(result.getString(result.getColumnIndex(ID)),
//                        result.getString(result.getColumnIndex(NAME_M))))
//            } while (result.moveToNext())
//        }
//
//        result.close()
//        db.close()


//

//







